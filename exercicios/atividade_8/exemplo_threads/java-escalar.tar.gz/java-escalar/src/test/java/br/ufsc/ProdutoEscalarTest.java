package br.ufsc;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class ProdutoEscalarTest {

    private void testCompute(ProdutoEscalar obj, int size) {
        List<Double> a = new ArrayList<>();
        List<Double> b = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            a.add(Math.random()*1000);
            b.add(Math.random()*1000);
        }

        double expected  = 0;
        for (int i = 0; i < size; i++) expected += a.get(i) * b.get(i);

        Assert.assertEquals(expected, obj.compute(a, b), 0.0001);
    }

    private void testCompute(ProdutoEscalar obj) {
        testCompute(obj, 1);
        testCompute(obj, 2);
        testCompute(obj, 777);
    }

    @Test
    public void testComputeThreadsOne() {
        ProdutoEscalarThreads obj = new ProdutoEscalarThreads();
        obj.setNumThreads(1);
        testCompute(obj);
    }
    @Test
    public void testComputeThreadsFour() {
        ProdutoEscalarThreads obj = new ProdutoEscalarThreads();
        obj.setNumThreads(4);
        testCompute(obj);
    }
    @Test
    public void testComputeThreadsDefault() {
        testCompute(new ProdutoEscalarThreads());
    }

    @Test
    public void testComputeExecutorOne() {
        ProdutoEscalarExecutor obj = new ProdutoEscalarExecutor();
        obj.setNumThreads(1);
        testCompute(obj);
    }
    @Test
    public void testComputeExecutorFour() {
        ProdutoEscalarExecutor obj = new ProdutoEscalarExecutor();
        obj.setNumThreads(4);
        testCompute(obj);
    }
    @Test
    public void testComputeExecutorDefault() {
        testCompute(new ProdutoEscalarExecutor());
    }
}