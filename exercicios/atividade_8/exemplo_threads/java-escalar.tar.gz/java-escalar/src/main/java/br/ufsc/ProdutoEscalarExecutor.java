package br.ufsc;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class ProdutoEscalarExecutor implements ProdutoEscalar {
    private int numThreads = Runtime.getRuntime().availableProcessors();

    @Override
    public void setNumThreads(int numThreads) {
        this.numThreads = numThreads;
    }

    @Override
    public int getNumThreads() {
        return numThreads;
    }

    @Override
    public double compute(@Nonnull final List<Double> a, @Nonnull final List<Double> b) {
        if (a.size() != b.size())
            throw new IllegalArgumentException("a.size() != b.size()");

        ExecutorService ex = Executors.newFixedThreadPool(numThreads);
        int chunk = a.size()/numThreads;

        ArrayList<Future<Double>> futures = new ArrayList<>();
        for (int i = 0; i < numThreads; i++) {
            final int begin = i*chunk;
            final int end = i == numThreads-1 ? a.size() : (i+1)*chunk;
            futures.add(ex.submit(new Callable<Double>() {
                @Override
                public Double call() {
                    double sum = 0;
                    for (int j = begin; j < end; j++) {
                        sum += a.get(j) * b.get(j);
                    }
                    return sum;
                }
            }));
        }

        double result = 0;
        for (Future<Double> future : futures) {
            try {
                result += future.get();
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        ex.shutdown();
        try {
            ex.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException ignored) {}

        return result;
    }
}
