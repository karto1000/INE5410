package br.ufsc;

import javax.annotation.Nonnull;
import java.util.List;

public interface ProdutoEscalar {
    void setNumThreads(int numThreads);
    int getNumThreads();
    double compute(@Nonnull List<Double> a, @Nonnull List<Double> b);
}
