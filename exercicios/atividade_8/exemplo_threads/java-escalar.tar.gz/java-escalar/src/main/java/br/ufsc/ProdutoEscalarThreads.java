package br.ufsc;

import javax.annotation.Nonnull;
import java.util.List;

public class ProdutoEscalarThreads implements ProdutoEscalar {
    private int numThreads = Runtime.getRuntime().availableProcessors();

    @Override
    public void setNumThreads(int numThreads) {
        this.numThreads = numThreads;
    }

    @Override
    public int getNumThreads() {
        return numThreads;
    }

    @Override
    public double compute(@Nonnull final List<Double> a, @Nonnull final List<Double> b) {
        if (a.size() != b.size())
            throw new IllegalArgumentException("a.size() != b.size()");

        Thread workers[] = new Thread[numThreads];
        final double sums[] = new double[numThreads];
        int chunk = a.size()/numThreads;

        for (int i = 0; i < numThreads; i++) {
            final int begin = i*chunk;
            final int end = i == numThreads-1 ? a.size() : (i+1)*chunk;
            final int threadNum = i;
            workers[i] = new Thread(new Runnable() {
                @Override
                public void run() {
                    double sum = 0;
                    for (int j = begin; j < end; j++)
                        sum += a.get(j) * b.get(j);
                    sums[threadNum] = sum;
                }
            });
            workers[i].start();
        }

        double result = 0;
        for (int i = 0; i < numThreads; i++) {
            try {
                workers[i].join();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            result += sums[i];
        }

        return result;
    }
}
